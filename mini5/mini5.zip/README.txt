Works with Chrome.

URL: https://www.cs.mcgill.ca/~lhu26/mini5/blog5.html

It works well at:
1) 425*734px for phone view
2) 768*734px for tablet view
3) 1024*734px for PC view

Please use the inspect view (broswer full screen with the dock size of DevTools = "undock into separate window" ) if necessary.

size range:
phone: 320px - 425px
tablet: 426px - 768px
PC: >768px

Thank you for grading! Have a good one!