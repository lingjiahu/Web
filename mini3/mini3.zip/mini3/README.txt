Works with Chrome, mac 13 inch screen.

lorem ipsum: https://www.lipsum.com/

coluors:
BG1: deepest green/ purple: 1E4240/ 7E1E80
BG2: medium green/ purple: 398164/ 9d449e
BG3: light green/ purple: 84AF88/ c46bc5
BG4: mild green/ purple: D2D7CE/ EFDCF9
T1: bright green/ purple: 348E00/ A020F0
T2: link green/ purple: 738E73/ D7A1F9


Thank you for grading! Have a good one :)
